/**
 * Screen saver to display code to run javaFX animations
 * 1. Main.java class contains main method to run JAVA 2D animation.
 * 2. Main.java class inherits Frame from MyFrame class.
 * 3. When main method is run a window should launch and a 2D animation should play
 @author (Hassan Ali 21327289 and Andre Costa Barros 21307237 )
  * @version (04/04/2022)
 */
package com.company;



public class Main {

    public static void main(String[] args) {
	 new MyFrame(); // from MyFrame method, runs the frame

    }
}
