/**
 * MyFrame.java class extends JFrame
 * 1. MyFrame.java creates frame for animation
 * 2. It in inherits the panel from the MyPanel.java class so panel can be added to frame
 */
package com.company;

import javax.swing.*;
import java.awt.*;

public class MyFrame extends JFrame {
    MyPanel panel1;

    MyFrame(){
        panel1 = new MyPanel();//from myPanel class, adds panel to frame

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// stops app from running in background when closed
        this.add(panel1); //adds panel to frame
        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true); // makes frame visible

    }
}
