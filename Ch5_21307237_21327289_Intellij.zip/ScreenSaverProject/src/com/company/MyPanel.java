/**
 * MyPanel.java creates panel for animation
 * 1. Panel is created and its dimensions are set
 * 2. Images are added to variable and added to panel
 * 3. Timer is set to tell java how often the commands repeat (how fast image moves)
 * 3. Images are animated
 * 4. Image moving and bouncing along panel mechanic is set
 */
package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class MyPanel extends JPanel implements ActionListener {
    final int WIDTH = 500; //panel width
    final int HEIGHT = 500;//panel height
    Image Sonic;
    Image backGround;
    Timer timer;
    int yVelocity = 6; //movement for item in y-axis
    int xVelocity = 5; // movement for item in x-axis
    int x = 0; // x and y are coordinates
    int y = 0;


    MyPanel() { //panel method
        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));// panel size(when .pack is used)
        this.setBackground(Color.BLACK);// sets panel colour to grey
        Sonic = new ImageIcon("src/sanic1.png").getImage();//set png file to sonic variable
        backGround = new ImageIcon("src/1.jpg").getImage();// sets png file to background variable
        timer = new Timer(1, this::actionPerformed); // the delay for image moving from pixel to pixel(in milliseconds)
        timer.start();// starts action
    }

    public void paint(Graphics a) {

        Graphics2D a2D = (Graphics2D) a;
        a2D.drawImage(backGround, 0, 0, this); //add background

        a2D.drawImage(Sonic, x, y, this);// adds image

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (x >= HEIGHT - Sonic.getWidth(null) || x < 0) { // makes image bounce off window(for x-axis)
            xVelocity = xVelocity * -1;
        }
        x += xVelocity; // makes image of sonic move in x-axis
        if (y >= HEIGHT - Sonic.getWidth(null) || y < 0) { // makes image bounce off window(for  y-axis)
            yVelocity = yVelocity * -1;
        }
        y += yVelocity; // makes image of sonic move in y-axis

        repaint();// makes image move without resizing window(makes animation)

    }
}

